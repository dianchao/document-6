package com.atguigu.maven.pojo;

/**
 * Date:2023/10/30
 * Author:ybc
 * Description:
 */
public class Student {

    public void sayHello(){

    }

}
