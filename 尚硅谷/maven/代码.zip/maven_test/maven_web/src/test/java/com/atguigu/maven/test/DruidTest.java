package com.atguigu.maven.test;

import org.junit.jupiter.api.Test;

/**
 * Date:2023/10/30
 * Author:ybc
 * Description:
 */
public class DruidTest {

    @Test
    public void testDruid(){

    }

}
