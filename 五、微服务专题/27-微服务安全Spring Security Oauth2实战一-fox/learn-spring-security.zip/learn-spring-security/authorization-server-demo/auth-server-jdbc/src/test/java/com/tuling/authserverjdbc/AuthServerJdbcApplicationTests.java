package com.tuling.authserverjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServerJdbcApplicationTests {

    @Test
    void contextLoads() {
    }

}
