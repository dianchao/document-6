package com.tuling.ssomallproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoMallProductApplicationTests {

    @Test
    void contextLoads() {
    }

}
