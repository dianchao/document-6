package com.tuling.helloworld02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Helloworld02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
