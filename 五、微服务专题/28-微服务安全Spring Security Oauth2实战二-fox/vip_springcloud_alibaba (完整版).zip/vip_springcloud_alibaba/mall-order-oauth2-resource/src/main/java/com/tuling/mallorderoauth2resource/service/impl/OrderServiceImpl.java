package com.tuling.mallorderoauth2resource.service.impl;

import com.tuling.mallorderoauth2resource.dao.OrderDao;
import com.tuling.mallorderoauth2resource.entity.OrderEntity;
import com.tuling.mallorderoauth2resource.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service("orderService")
public class OrderServiceImpl  implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Override
    public List<OrderEntity> listByUserId(Integer userId) {
        return orderDao.listByUserId(userId);
    }

    @Override
    public List<OrderEntity> listByUserIdAndCommodityCode(Integer userId, String commodityCode) {
        return orderDao.listByUserIdAndCommodityCode(userId,commodityCode);
    }


}