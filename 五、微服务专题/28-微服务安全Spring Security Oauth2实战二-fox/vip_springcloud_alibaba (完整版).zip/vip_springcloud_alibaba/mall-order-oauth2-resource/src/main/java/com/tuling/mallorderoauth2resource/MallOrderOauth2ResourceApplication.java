package com.tuling.mallorderoauth2resource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallOrderOauth2ResourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallOrderOauth2ResourceApplication.class, args);
    }

}
