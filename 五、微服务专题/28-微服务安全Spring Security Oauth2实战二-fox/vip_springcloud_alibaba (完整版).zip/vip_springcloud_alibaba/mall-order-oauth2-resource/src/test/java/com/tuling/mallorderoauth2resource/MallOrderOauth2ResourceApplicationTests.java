package com.tuling.mallorderoauth2resource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallOrderOauth2ResourceApplicationTests {

    @Test
    void contextLoads() {
    }

}
