package com.tuling.mallgatewayoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallGatewayOauth2Application {

    public static void main(String[] args) {
        SpringApplication.run(MallGatewayOauth2Application.class, args);
    }

}
