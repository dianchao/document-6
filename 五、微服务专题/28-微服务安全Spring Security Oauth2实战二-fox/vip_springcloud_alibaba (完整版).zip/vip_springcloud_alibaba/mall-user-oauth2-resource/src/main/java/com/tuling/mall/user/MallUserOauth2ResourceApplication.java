package com.tuling.mall.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients //扫描和注册feign客户端bean定义
public class MallUserOauth2ResourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallUserOauth2ResourceApplication.class, args);
    }

}
