package com.tuling.sentineltokenserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentinelTokenServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
