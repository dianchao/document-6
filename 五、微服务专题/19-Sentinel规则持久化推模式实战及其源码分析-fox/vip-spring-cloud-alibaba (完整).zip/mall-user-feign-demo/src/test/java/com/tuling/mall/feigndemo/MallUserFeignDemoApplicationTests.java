package com.tuling.mall.feigndemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallUserFeignDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
