package com.tuling;

public @interface Fox {

}
