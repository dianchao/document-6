package com.jd.platform.hotkey.worker.config;

//import com.jd.ump.annotation.JAnnotation;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author wuweifeng
 * @version 1.0
 * @date 2020-05-07
 */
@Configuration
public class Ump {

    /*@Bean
    public JAnnotation jAnnotation() {
        JAnnotation jAnnotation = new JAnnotation();
        jAnnotation.setJvmKey("hotkey.jvm");
        jAnnotation.setSystemKey("hotkey.system");
        return jAnnotation;
    }*/
}
