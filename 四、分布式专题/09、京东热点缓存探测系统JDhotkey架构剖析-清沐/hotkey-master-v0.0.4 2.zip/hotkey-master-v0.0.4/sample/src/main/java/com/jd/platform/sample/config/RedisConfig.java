package com.jd.platform.sample.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author wuweifeng wrote on 2017/10/27.
 */
@Configuration
public class RedisConfig {
//
//    @Bean(name = {"redisTemplate", "stringRedisTemplate"})
//    public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory factory) {
//        StringRedisTemplate redisTemplate = new StringRedisTemplate();
//        redisTemplate.setConnectionFactory(factory);
//        return redisTemplate;
//    }

}
