package com.jd.platform.hotkey.client;

/**
 * @author wuweifeng wrote on 2019-12-05
 * @version 1.0
 */
public class Context {
    public static String APP_NAME;

    public static int CAFFEINE_SIZE;
}
