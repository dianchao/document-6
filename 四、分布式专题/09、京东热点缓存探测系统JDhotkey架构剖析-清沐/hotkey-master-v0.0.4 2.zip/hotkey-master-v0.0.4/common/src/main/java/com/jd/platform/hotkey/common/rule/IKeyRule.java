package com.jd.platform.hotkey.common.rule;

/**
 * @author wuweifeng wrote on 2020-02-26
 * @version 1.0
 */
public interface IKeyRule {
    KeyRule getKeyRule();
}
