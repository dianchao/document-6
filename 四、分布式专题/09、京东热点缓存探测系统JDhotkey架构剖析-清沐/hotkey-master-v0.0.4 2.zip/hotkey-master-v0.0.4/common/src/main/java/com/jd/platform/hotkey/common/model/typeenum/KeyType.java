package com.jd.platform.hotkey.common.model.typeenum;

/**
 * @author wuweifeng wrote on 2019-12-10
 * @version 1.0
 */
public enum KeyType {
    REDIS_KEY,
    REQUEST_PATH,
    BLACK_LIST,
    OTHER
}
